import './src/polyfills'; // <-- ADICIONE ESTA LINHA NO TOP
import { Link } from 'expo-router';
import { View, StyleSheet, Text, Pressable } from 'react-native';
import * as Haptics from 'expo-haptics';

export default function Home() {
  const onPress = () => Haptics.selectionAsync().catch(() => {});
  return (
    <View style={styles.container}>
      <Text style={styles.title}>ChromAid</Text>
      <Text style={styles.subtitle}>Identifique cores com um toque</Text>

      <Link href="/camera-live" asChild onPress={onPress}>
        <Pressable style={({ pressed }) => [styles.button, styles.buttonPrimary, pressed && styles.pressed]}>
          <Text style={[styles.buttonText, styles.buttonPrimaryText]}>Abrir câmera</Text>
        </Pressable>
      </Link>

      <Pressable style={[styles.button, styles.buttonGhost]} disabled>
        <Text style={[styles.buttonText, styles.buttonGhostText]}>Segundo botão (em breve)</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 24, gap: 20, justifyContent: 'center' },
  title: { fontSize: 34, fontWeight: '700', textAlign: 'center' },
  subtitle: { fontSize: 16, color: '#6b7280', textAlign: 'center' },
  button: { paddingVertical: 16, borderRadius: 14, alignItems: 'center' },
  buttonPrimary: { backgroundColor: '#0a84ff' },
  buttonPrimaryText: { color: 'white' },
  buttonGhost: { backgroundColor: '#f3f4f6', opacity: 0.6 },
  buttonGhostText: { color: '#6b7280' },
  buttonText: { fontSize: 17, fontWeight: '600' },
  pressed: { opacity: 0.85 },
});
