import Home from "../index";

export default function App() {
    return <Home />
}